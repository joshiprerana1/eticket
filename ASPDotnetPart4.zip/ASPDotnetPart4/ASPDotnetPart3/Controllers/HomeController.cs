﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ASPDotnetPart4.Models;
using Microsoft.AspNetCore.Http;

namespace ASPDotnetPart4.Controllers
{
    public class HomeController : Controller
    {
        
        public IActionResult Index()
        {
            
            TempData["td"] = "Hello";
            //var x = TempData["td"]; // reading
            //TempData.Keep("td");  // persist next
            var x = TempData.Peek("td");
            return View();
            //return RedirectToAction("Index1");
        }
        public IActionResult Index1()
        {
            
            return View("Index");
        }
        public IActionResult Indext()
        {
            
             return View();
            //return RedirectToAction("Index1");
        }
        
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

       

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
