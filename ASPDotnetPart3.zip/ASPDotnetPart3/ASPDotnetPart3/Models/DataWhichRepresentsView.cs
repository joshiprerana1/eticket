﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPDotnetPart3.Models
{
    public class DataWhichRepresentsView
    {
        public string vd { get; set; }
        public string oneMoreVd { get; set; }
    }
}
