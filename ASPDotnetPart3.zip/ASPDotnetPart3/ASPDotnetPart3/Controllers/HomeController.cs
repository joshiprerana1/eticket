﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ASPDotnetPart3.Models;
using Microsoft.AspNetCore.Http;

namespace ASPDotnetPart3.Controllers
{
    public class HomeController : Controller
    {
        string x = "";
        public IActionResult Index()
        {
            DataWhichRepresentsView x = new DataWhichRepresentsView();
            x.vd = "Hello";
            x.oneMoreVd = "ddd";
            ViewData["vd"] = "Hello";
           
           // return View();
           return View(x);
        }
        public IActionResult Index1()
        {
            return View("Index");
        }
        public IActionResult Indext()
        {
            TempData["td"] ="Hello";
            //var t = TempData["td"];
            //TempData.Keep("td");
            x = "ddd";
             return View();
            //return RedirectToAction("Index1");
        }
        
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

       

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
